import java.util.Scanner;
public class StringEquality {
   
    
}

