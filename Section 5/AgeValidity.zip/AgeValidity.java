import java.util.Scanner;

public class AgeValidity {

    public static void main(String[] args) {

       
    }
}
