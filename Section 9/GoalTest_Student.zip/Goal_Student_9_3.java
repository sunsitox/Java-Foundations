public class Goal_Student_9_3 {

    public Goal_Student_9_3(){

        
        GoalTest_Student_9_3.root.getChildren().addAll();
        interactions();
    }
    
    private void interactions(){
        //Exercise 4   
        
    }
}
