import java.util.Scanner;

public class ComputeAvg {

    public static void main(String args[]) {

        
    }

}
