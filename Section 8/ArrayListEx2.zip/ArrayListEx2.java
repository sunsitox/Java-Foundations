import java.util.ArrayList;

public class ArrayListEx2 {
    public static void main(String args[]) {
        
        
        
        
        
        
         
    }
}
