public class Chickens01 {
    public static void main(String[] args) {
        //Put yout code here
        
        System.out.println(totalEggs);
    }   
}
