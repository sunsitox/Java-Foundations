public class ShoppingCart02 {
    public static void main(String[] args) {
        String custName = "Alex";
        String itemDesc = "Shirts";
        String message = custName+" wants to purchase a "+itemDesc;
        
        // Declare and initialize numeric fields: price, tax, quantity.   
        
        
        
        // Declare and assign a calculated totalPrice
        
        
        // Modify message to include quantity 
        
        System.out.println(message);
        
        // Print another message with the total cost
        
    }    
}
