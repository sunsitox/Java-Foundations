//Section 7, Lesson 3 Starter for Exercise 1 - Slide 6

public class PrisonTest_Student_7_3 {

    public static void main(String[] args) {

    } 
}
