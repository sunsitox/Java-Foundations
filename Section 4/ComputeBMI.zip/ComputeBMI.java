
import java.util.Scanner;


public class ComputeBMI {
    public static void main(String[] args)
	{
            
        
        }
}
