
public class RockPaperScissor {

    public static void main(String[] args) {
        

    }
}
